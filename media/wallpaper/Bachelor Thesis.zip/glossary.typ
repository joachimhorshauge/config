#let entry-list = (
    (
    // a term with a markup description
    (
      key: "plm",
      short: "PLM",
      long: "Product Lifecycle Management",
      description: [Product Lifecycle Management (PLM) is the business activity of managing, in the
most effective way, a company’s products all the way across their lifecycles; from
the very first idea for a product all the way through until it is retired and disposed of. #cite(<Stark2022>, supplement: [p. 1])],
      group: "Acronyms",
    ),
  )
)