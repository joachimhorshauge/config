#let project(
  title: "",
  abstract: [],
  authors: (),
  date: none,
  department: "",
  university: "",
  ects: 15,
  advisor: "",
  glossary: true,
  body,
) = {
  // ─────────────────────────────────────────────────────────────
  // Document setup
  // ─────────────────────────────────────────────────────────────
  set document(author: authors.map(a => a.name), title: title)
  set page(
    margin: (left: 35mm, right: 35mm, top: 30mm, bottom: 30mm),
    numbering: none,
    number-align: center,
  )
  set text(font: "Noto Sans", lang: "en")
  show math.equation: set text(weight: 400)

  // ─────────────────────────────────────────────────────────────
  // Title page
  // ─────────────────────────────────────────────────────────────
  v(12em)
  line(length: 100%, stroke: 2pt)

  align(left)[
    #text(weight: 500, 2em, title)
    #v(2em, weak: true)
    #for author in authors {
      text(weight: 400, 1.25em, [#author.name, #author.student_id #linebreak()])
    }
  ]

  line(length: 100%, stroke: 2pt)

  v(2em)
  
  text(weight: 400, 1.25em, [
    Bachelor Report (#ects ECTS) in Computer Science #linebreak()
    Advisor: #advisor #linebreak()
    Department of #department, #university #linebreak()
    #date
  ])
  
  set text(font: "New Computer Modern", lang: "en")

  place(
    bottom,
    float: true,
    image(width: 50%, "figure/image/logo.png"),
  )

  pagebreak()

  // ─────────────────────────────────────────────────────────────
  // Front matter (roman numerals, starting at ii)
  // ─────────────────────────────────────────────────────────────
  set page(numbering: "i")
  counter(page).update(2)
  set par(justify: true)

  // Abstract
  heading(
    outlined: false,
    numbering: none,
    text(0.85em, smallcaps[Abstract]),
  )
  abstract
  pagebreak()

  // ─────────────────────────────────────────────────────────────
  // Heading styles
  // ─────────────────────────────────────────────────────────────

  // Chapter (level 1)
  show heading.where(level: 1): it => {
    pagebreak(weak: true)
    v(4em)
    set text(font: "New Computer Modern", weight: 700)
    if it.numbering != none {
      block(text(size: 1.25em, [Chapter ] + counter(heading).display()))
      v(0.5em)
    }
    block(text(size: 1.5em, it.body))
    v(2em)
  }

  // Section (level 2)
  show heading.where(level: 2): it => {
    v(1.5em)
    set text(font: "New Computer Modern", weight: 600, size: 1.2em)
    block(counter(heading).display() + h(0.5em) + it.body)
    v(0.5em)
  }

  // Subsection (level 3)
  show heading.where(level: 3): it => {
    v(1em)
    set text(font: "New Computer Modern", weight: 600, size: 1.1em)
    block(counter(heading).display() + h(0.5em) + it.body)
    v(0.3em)
  }

  // Table of contents
  outline(title: [Contents])
  pagebreak()

  // ─────────────────────────────────────────────────────────────
  // Main body (arabic numerals, starting at 1)
  // ─────────────────────────────────────────────────────────────
  set page(numbering: "1")
  counter(page).update(1)
  set heading(numbering: "1.1")

  body

  // ─────────────────────────────────────────────────────────────
  // Bibliography
  // ─────────────────────────────────────────────────────────────
  pagebreak()
  bibliography("bibliography.bib")

  // ─────────────────────────────────────────────────────────────
  // Appendix
  // ─────────────────────────────────────────────────────────────
  pagebreak()

  // Reset heading counter and switch to letter numbering for appendix
  counter(heading).update(0)
  set heading(numbering: "A.1")
  
  show heading.where(level: 1): it => {
    pagebreak(weak: true)
    v(4em)
    set text(font: "New Computer Modern", weight: 600)
    if it.numbering != none {
      block(text(size: 1.2em, [Appendix ] + counter(heading).display()))
      v(0.5em)
    }
    block(text(size: 1.5em, it.body))
    v(2em)
  }

    
  // ─────────────────────────────────────────────────────────────
  // Glossary
  // ─────────────────────────────────────────────────────────────
  import "@preview/glossarium:0.5.10": make-glossary, register-glossary, print-glossary, gls, glspl
  import "glossary.typ": entry-list

  show: make-glossary
  register-glossary(entry-list)
  print-glossary(entry-list)

  
  include "sections/appendix.typ"
}