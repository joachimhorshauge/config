#import "@preview/cetz:0.3.4"

#set page(width: auto, height: auto, margin: 8pt)

#cetz.canvas(length: 1cm, {
  import cetz.draw: *

  // ============== Layout parameters ==============
  let left-edge = 0
  let right-edge = 26
  let label-x = 0.7
  let lane-start = 1.4

  // Lanes: (id, label, top-y, height)
  let lanes = (
    ("R1",  "R1",  0,     -1.8),
    ("R2",  "R2",  -1.8,  -1.6),
    ("R3",  "R3",  -3.4,  -2.6),
    ("R4",  "R4",  -6.0,  -2.0),
    ("R5",  "R5",  -8.0,  -1.4),
    ("R6",  "R6",  -9.4,  -1.4),
    ("R7",  "R7",  -10.8, -1.6),
    ("R8",  "R8",  -12.4, -1.6),
    ("PLM", "PLM", -14.0, -2.2),
  )

  // ============== Swimlane structure ==============
  rect((left-edge, 0.4), (right-edge, -16.2), stroke: 0.6pt + gray)
  for lane in lanes {
    let (_, lbl, ytop, h) = lane
    line((left-edge, ytop), (right-edge, ytop), stroke: 0.5pt + gray)
    content((label-x, ytop + h/2), text(size: 9pt, lbl))
    line((lane-start, ytop), (lane-start, ytop + h), stroke: 0.4pt + gray)
  }
  line((left-edge, -16.2), (right-edge, -16.2), stroke: 0.5pt + gray)

  // ============== Style ==============
  let box-stroke = 0.6pt + black
  let box-fill = rgb("#f2f2f2")
  let arr = (mark: (end: "stealth", fill: black, scale: 0.5),
             stroke: 0.5pt + black)

  let pbox(pos, label, w: 1.6, h: 1.0) = {
    let (cx, cy) = pos
    rect((cx - w/2, cy - h/2), (cx + w/2, cy + h/2),
         stroke: box-stroke, fill: box-fill)
    content(pos, text(size: 8pt)[#align(center, label)])
  }

  let diamond(pos, label, w: 1.7, h: 1.3) = {
    let (cx, cy) = pos
    line((cx, cy + h/2), (cx + w/2, cy),
         (cx, cy - h/2), (cx - w/2, cy),
         close: true, stroke: box-stroke, fill: box-fill)
    content(pos, text(size: 7.5pt)[#align(center, label)])
  }

  // Oval (stadium) — single closed path so there's no internal artifacts
  let oval(pos, label, w: 1.2, h: 0.6) = {
    let (cx, cy) = pos
    let r = h/2
    let lx = cx - w/2 + r   // center of left semicircle
    let rx = cx + w/2 - r   // center of right semicircle
    merge-path(close: true, stroke: box-stroke, fill: box-fill, {
      // start at top-left tangent, go right along top
      line((lx, cy + r), (rx, cy + r))
      // right semicircle (top to bottom, clockwise -> sweep from 90 to -90)
      arc((rx, cy + r), start: 90deg, delta: -180deg, radius: r, anchor: "arc-start")
      // bottom line right to left
      line((rx, cy - r), (lx, cy - r))
      // left semicircle (bottom to top)
      arc((lx, cy - r), start: 270deg, delta: -180deg, radius: r, anchor: "arc-start")
    })
    content(pos, text(size: 8pt, label))
  }

  let doc-shape(pos, label, w: 1.6, h: 1.2) = {
    let (cx, cy) = pos
    let left = cx - w/2
    let right = cx + w/2
    let top = cy + h/2
    let bot = cy - h/2 + 0.15
    merge-path(close: true, fill: white, stroke: box-stroke, {
      line((left, top), (right, top))
      line((right, top), (right, bot))
      bezier((right, bot), (left, bot),
             (right - w*0.3, bot - 0.25),
             (left + w*0.3, bot + 0.25))
      line((left, bot), (left, top))
    })
    content((cx, cy + 0.08), text(size: 8pt)[#align(center, label)])
  }

  let lbl(pos, txt) = content(pos, text(size: 7pt, txt))

  // ============== R1 ==============
  oval((2.2, -0.9), "S1")
  pbox((4.2, -0.9), [Create\ Problem\ Report])
  line((2.85, -0.9), (3.4, -0.9), ..arr)

  // ============== R2 ==============
  oval((5.7, -2.6), "S2")
  pbox((7.4, -2.6), [Create\ ECR])
  line((6.35, -2.6), (6.6, -2.6), ..arr)

  // R1 -> R3
  line((4.2, -1.4), (4.2, -1.55), (2.2, -1.55), (2.2, -4.2), ..arr)

  // ============== R3 ==============
  pbox((2.2, -4.7), [Analyse\ PR])
  diamond((4.5, -4.7), [Accept\ PR?])
  pbox((7.4, -4.7), [Create\ ECR])
  line((3.0, -4.7), (3.65, -4.7), ..arr)
  line((5.35, -4.7), (6.6, -4.7), ..arr)
  lbl((6.0, -4.5), "Yes")

  pbox((6.4, -3.7), [Inform R1\ of reasons], w: 1.7, h: 0.8)
  line((4.5, -4.05), (4.5, -3.7), (5.55, -3.7), ..arr)
  lbl((4.85, -3.55), "No")

  pbox((9.6, -4.0), [Analyse\ ECR])
  diamond((11.8, -4.0), [Looks\ OK?])
  line((7.4, -3.1), (7.4, -3.5), (9.6, -3.5), (9.6, -3.5), ..arr)
  line((10.4, -4.0), (10.95, -4.0), ..arr)

  pbox((13.8, -3.2), [Inform R2\ of reasons], w: 1.7, h: 0.8)
  line((11.8, -3.35), (11.8, -3.2), (12.95, -3.2), ..arr)
  lbl((12.2, -3.05), "N")

  diamond((14.4, -4.0), [Full /\ Fast?])
  pbox((16.7, -4.0), [Create\ ECN])
  line((12.65, -4.0), (13.55, -4.0), ..arr)
  lbl((13.1, -3.8), "Y")
  line((15.25, -4.0), (15.9, -4.0), ..arr)
  lbl((15.55, -3.8), "Fast")

  // Accept PR Yes path: Create ECR(R3) -> down/right into Full/Fast?
  line((8.2, -4.7), (8.7, -4.7), (8.7, -5.4), (14.4, -5.4), (14.4, -4.65), ..arr)

  // ============== R4 ==============
  pbox((10.6, -7.0), [Review\ ECR])
  diamond((12.8, -7.0), [Makes\ business\ sense?], w: 1.9, h: 1.5)
  line((14.4, -4.65), (14.4, -5.9), (10.6, -5.9), (10.6, -6.5), ..arr)
  lbl((12.5, -5.75), "Full")
  line((11.4, -7.0), (11.85, -7.0), ..arr)

  pbox((15.0, -6.3), [Inform R3\ of reasons], w: 1.7, h: 0.8)
  line((12.8, -6.25), (12.8, -6.3), (14.15, -6.3), ..arr)
  lbl((13.2, -6.05), "N")

  // ============== R5 ==============
  pbox((13.6, -8.7), [Create\ ECN], h: 0.9)
  line((12.8, -7.75), (12.8, -8.3), (13.6, -8.3), (13.6, -8.25), ..arr)
  lbl((12.55, -8.0), "Y")

  // ============== R6 ==============
  pbox((15.4, -10.1), [Review\ ECN])
  diamond((18.0, -10.1), [Plan OK?\ Go ahead\ with ECN?], w: 2.4, h: 1.6)
  line((13.6, -9.15), (13.6, -9.6), (15.4, -9.6), (15.4, -9.6), ..arr)

  // R3 Create ECN -> Review ECN (long down then into right side)
  line((16.7, -4.5), (16.7, -10.1), (16.25, -10.1), ..arr)
  line((16.2, -10.1), (16.8, -10.1), ..arr)

  pbox((21.5, -10.1), [Inform R3 of reasons], w: 2.2, h: 0.8)
  line((19.2, -10.1), (20.4, -10.1), ..arr)
  lbl((19.7, -9.9), "N")

  // ============== R7 ==============
  pbox((19.8, -11.6), [Make\ changes,\ Review])
  line((18.0, -10.9), (18.0, -11.6), (19.0, -11.6), ..arr)
  lbl((17.75, -11.4), "Y")

  // ============== R8 ==============
  pbox((19.8, -13.2), [Audit\ changes])
  diamond((22.0, -13.2), [All OK?])
  pbox((24.0, -13.2), [Release\ ECN])
  line((19.8, -12.1), (19.8, -12.7), ..arr)
  line((20.6, -13.2), (21.15, -13.2), ..arr)
  line((22.85, -13.2), (23.2, -13.2), ..arr)
  lbl((23.0, -13.0), "Yes")

  // All OK? No -> back to Make changes (loop above the box)
  line((22.0, -12.55), (22.0, -10.95), (19.8, -10.95), (19.8, -11.1), ..arr)
  lbl((20.8, -10.8), "No")

  // ============== PLM row ==============
  doc-shape((2.5, -15.1), [Problem\ Report])
  doc-shape((5.8, -15.1), [ECR])
  doc-shape((8.5, -15.1), [Analysis\ Report])
  doc-shape((12.0, -15.1), [ECN])
})
