#import "@preview/glossarium:0.5.10": gls, glspl

= Development
== Contents
In this chapter we look at a typical software development workflow for a mid size company, we identify the core principles and potential problems of such a workflow, relate software development to engineering change management (ECM) in product lifecycle management (PLM), and propose that a process ontological mindset can mitigate problems occuring due to missing context in the development phase of changes.


== Product Lifecycle Management
#gls("plm") PLM is the business activity in production/construction companies of effectively managing a company's product throughout their whole life-cycle. #cite(<Stark2022>, supplement: "p. 1"), from the idea of a product all though development, use, service and retirement of the product. Within the PLM umbrella, there is a business process called Engineering Change Management (ECM)