#import "template.typ": *

// Take a look at the file `template.typ` in the file panel
// to customize this template and discover how it works.
#show: project.with(
  title: "Something about Computer Science (Noget om Datalogi)",
  authors: (
    (name: "Joachim Horshauge", student_id: "202005714"),
    (name: "Morten Fausing", student_id: "000000000"),
  ),
  // Insert your abstract after the colon, wrapped in brackets.
  // Example: `abstract: [This is my abstract...]`
  abstract: include "sections/abstract.typ",
  date: "May, 2026",
  department: "Computer Science",
  university: "Aarhus University",
  ects: 15,
  advisor: "Olav W. Bertelsen", // Name of your advisor
)


// Section 4
#include "sections/development.typ"
